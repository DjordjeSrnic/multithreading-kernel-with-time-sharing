/*
 * PCB.h
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */

#ifndef PCB_H_
#define PCB_H_

#include "thread.h"

class PCB {
public:
   PCB(Thread* thread, Time timeSl, StackSize stackSize);
   PCB(unsigned int t, void(*fun)());
   PCB();
   unsigned ss;
   unsigned sp;
   unsigned bp;
   Time timeSlice;
   Time sleepTime;
   int done;
   int sleepf;
   int blockf;
   PCB* next;
   PCB* blocked;
   static PCB* running;
   void start();
   void waitToComplete();
   static void sleep(unsigned t);
private:
    static void wrapper();
    void prepareStack(void (*fun)(), StackSize);
    void finishThread();
    Thread* myThread;
};

#endif /* PCB_H_ */
