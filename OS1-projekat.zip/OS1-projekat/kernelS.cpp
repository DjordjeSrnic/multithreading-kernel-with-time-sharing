/*
 * kernelsem.cpp
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */

#include "kernelS.h"
#include "timer.h"
#include "help.h"

PCB* temp_;
PCB* prev;

KernelSem::KernelSem(int init)
{
	asm pushf
	asm cli
	initial=value = init;
    blocked = 0;
	asm popf
}

int KernelSem::val() const { return value; }

int KernelSem::wait()
{
	asm pushf
	asm cli
	if (--value<0)
	{
	    temp_=PCB::running;
		temp_->next=blocked;
		blocked=temp_;
		PCB::running->blockf=1;
		dispatch();
		asm popf
		return 1;
	}
	asm popf;
	return 0;
}

void KernelSem::signal()
{
	asm pushf
	asm cli
	if ((value++ < 0) && blocked)
	{
		temp_ = blocked;
		if (blocked->next == 0)
		{
			blocked->blockf=0;
			putInScheduler(blocked);
			blocked = 0;
		}
		else
		{
			while (temp_->next->next) temp_ = temp_->next;
			temp_->next->blockf=0;
			putInScheduler(temp_->next);
			temp_->next = 0;
			temp_ = 0;
		}
	}
	asm popf
}

