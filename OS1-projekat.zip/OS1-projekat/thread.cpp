/*
 * thread.cpp
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */

#include "thread.h"
#include "timer.h"

Thread::Thread (StackSize stackSize, Time timeSlice)
{
	myPCB=new PCB(this,timeSlice,stackSize);
}

Thread::~Thread() {}

void Thread::waitToComplete()
{
	myPCB->waitToComplete();
}

void Thread::sleep(Time timeToSleep)
{
	PCB::sleep(timeToSleep);
}

void Thread::start()
{
	myPCB->start();
}

void dispatch()
{
	timerDispatch();
}
