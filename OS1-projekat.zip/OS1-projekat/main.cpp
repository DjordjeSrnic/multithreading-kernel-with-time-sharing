/*
 * main.cpp
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */

#include "timer.h"
#include "thread.h"
#include "help.h"
#include "PCB.h"

extern int userMain(int argc, char* argv[]);
extern PCB* initial;

int ret;

int main(int argc, char* argv[])
{
	PCB::running=initial;
	inic();
	ret = userMain(argc, argv);
	restore();
	return ret;
}


