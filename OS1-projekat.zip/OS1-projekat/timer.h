/*
 * timer.h
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */

#ifndef TIMER_H_
#define TIMER_H_

void interrupt timer();

void timerDispatch();

void inic();

void restore();

void softlock();

void softunlock();

#endif /* TIMER_H_ */
