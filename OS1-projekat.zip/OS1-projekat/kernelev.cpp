/*
 * kernelev.cpp
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */

#include "kernelev.h"
#include "help.h"
#include <dos.h>

KernelEv* IVTEntry::kEvents[256];

KernelEv::KernelEv(IVTNo _ivtNo)
{
	asm pushf
	asm cli
	myThreadPCB=PCB::running;
	blockedThreadPCB=0;
	ivtNo=_ivtNo;
	IVTEntry::kEvents[ivtNo]=this;
	asm popf
}

KernelEv::~KernelEv()
{
	asm pushf
	asm cli
	IVTEntry::kEvents[ivtNo]=0;
	if (blockedThreadPCB)
    {
		blockedThreadPCB->blockf=0;
		putInScheduler(blockedThreadPCB);
		blockedThreadPCB=0;
	}
	asm popf
}

void KernelEv::signal()
{
	asm pushf
	asm cli
	if (blockedThreadPCB)
    {
	   blockedThreadPCB->blockf=0;
	   putInScheduler(blockedThreadPCB);
	   blockedThreadPCB=0;
	}
	dispatch();
	asm popf
}

void KernelEv::wait()
{
	asm pushf
	asm cli
	if (PCB::running==myThreadPCB)
    {
	   blockedThreadPCB=PCB::running;
	   PCB::running->blockf=1;
	   dispatch();
	}
	asm popf
}

IVTEntry::IVTEntry(IVTNo _ivtNo, pInterrupt _newHandle)
{
	asm pushf
	asm cli
	newHandle=_newHandle;
	ivtNo=_ivtNo;
	inic();
	asm popf
}

IVTEntry::~IVTEntry()
{
	restore();
}

void IVTEntry::inic()
{
	asm pushf
	asm cli
	#ifndef BCC_BLOCK_IGNORE
	oldHandle=getvect(ivtNo);
	setvect(ivtNo,newHandle);
	#endif
	asm popf
}

void IVTEntry::restore()
{
	#ifndef BCC_BLOCK_IGNORE
	setvect(ivtNo,oldHandle);
	#endif
}

void IVTEntry::signal()
{
	kEvents[ivtNo]->signal();
}

