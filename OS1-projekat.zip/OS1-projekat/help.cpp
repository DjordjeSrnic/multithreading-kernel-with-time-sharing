#include "help.h"
#include "SCHEDULE.h"
#include "PCB.h"

PCB* temp;

extern volatile int threadCount;

void loop() { while(threadCount); }

PCB* initial=new PCB();

PCB* idle=new PCB(1,loop);

void putInScheduler(PCB* thread)
{
    asm pushf
	asm cli
	if (thread!= idle && thread!=initial && !thread->done && !thread->blockf && !thread->sleepf)
		Scheduler::put(thread);
	asm popf
}

PCB* getFromScheduler()
{
    temp=Scheduler::get();
    if (temp) return temp;
    if (threadCount) return idle;
    else return initial;
}
