/*
 * semaphor.cpp
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */

#include "semaphor.h"
#include "kernelS.h"

Semaphore::Semaphore(int init)
{
	myImpl=new KernelSem(init);
}

Semaphore::~Semaphore()
{
	delete myImpl;
}

int Semaphore::wait(int toBlock)
{
	if (toBlock!=0)
    {
	   return myImpl->wait();
	}
	else
	{
	   if (val()<=0)
	   {
	       return -1;
	   }
	   else
       {
          return myImpl->wait();
       }
	}
}

void Semaphore::signal()
{
	myImpl->signal();
}

int Semaphore::val() const
{
	return myImpl->val();
}

