/*
 * PCB.cpp
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */

#include "PCB.h"
#include "help.h"
#include "timer.h"
#include <dos.h>

volatile int threadCount;

PCB* _temp;

PCB* finished=0;
PCB* sleeping=0;

PCB* PCB::running=0;


PCB::PCB(Thread* thread, Time timeSl, StackSize stackSize)
{
    asm pushf
    asm cli
    timeSlice = timeSl;
	myThread = thread;
	blocked = 0;
	next = 0;
	prepareStack(PCB::wrapper, stackSize);
	done = 0;
	sleepf=0;
	blockf=0;
	asm popf
}

PCB :: PCB(unsigned int t, void(*fun)())
{
	asm pushf
	asm cli
	timeSlice = t;
	next = 0;
	prepareStack(fun, 4096);
	done = 0;
	sleepf=0;
	blockf=0;
	asm popf
}

PCB::PCB()
{
    asm pushf
    asm cli
    timeSlice = defaultTimeSlice;
	myThread = 0;
	blocked = 0;
	next = 0;
	done = 0;
	sleepf=0;
	blockf=0;
	asm popf
}

void PCB::wrapper()
{
	asm cli
    PCB::running->myThread->run();
    threadCount--;
    PCB::running->finishThread();
    _temp = PCB::running;
    _temp->next = finished;
    finished = _temp;
    dispatch();
}

void PCB::prepareStack(void (*fun)(), StackSize stackSize)
{
    unsigned* stack = new unsigned[stackSize];
	stack[stackSize - 1] = 0x200;
	#ifndef BCC_BLOCK_IGNORE
	stack[stackSize - 2] = FP_SEG(fun);
	stack[stackSize - 3] = FP_OFF(fun);
	sp = FP_OFF(stack + stackSize - 12);
	ss = FP_SEG(stack + stackSize - 12);
	bp = sp;
	#endif

}

void PCB::finishThread()
{
	while(blocked)
    {
		blocked->blockf=0;
		_temp = blocked;
		putInScheduler(blocked);
		blocked = blocked->next;
		_temp->next = 0;
	}
	done = 1;
}

void PCB::start()
{
	asm pushf
	asm cli
	threadCount++;
	putInScheduler(this);
	done = 0;
	asm popf
}

void PCB::waitToComplete()
{
	asm pushf
	asm cli
	if (!done)
    {
		_temp = PCB::running;
        _temp->next = blocked;
        blocked = _temp;
        PCB::running->blockf=1;
        dispatch();
	}
	asm popf
}

void PCB::sleep(Time t)
{
	asm pushf
	asm cli
	PCB::running->sleepf=1;
	_temp=PCB::running;
    _temp->sleepTime=t;
    _temp->next=sleeping;
    sleeping=_temp;
    dispatch();
    asm popf
}
