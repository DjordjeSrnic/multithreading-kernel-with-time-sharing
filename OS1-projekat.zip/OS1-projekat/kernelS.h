/*
 * kernelsem.h
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */

#ifndef KERNELSEM_H_
#define KERNELSEM_H_

#include "semaphor.h"
#include "PCB.h"

class KernelSem {
public:
	KernelSem(int init);
	int wait();
	void signal();
	int val() const;
protected:
	friend class Semaphore;
private:
	PCB* blocked;
	int value;
	int initial;
};

#endif /* KERNELSEM_H_ */
