/*
 * timer.cpp
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */

#include "Timer.h"
#include "PCB.h"
#include "help.h"

unsigned tsp;
unsigned tss;
unsigned tbp;
unsigned context_switch_on_demand=0;
unsigned timeCounter = 20;

unsigned int lockflag = 0;
unsigned int zerotime = 0;

extern void tick();

extern PCB* sleeping;

PCB* _temp_;
PCB* _prev;
PCB* help;

extern void tick();

void softlock()
{
	asm pushf
	asm cli
	lockflag=1;
	asm popf
}

void softunlock()
{
	asm pushf
	asm cli
	lockflag=0;
	asm popf
}

void interrupt timer()
{
	if (timeCounter>0 && !context_switch_on_demand) { timeCounter--; zerotime=0; }
	else if (timeCounter==0) zerotime=1;
	if ((timeCounter == 0 && !zerotime && !lockflag) || context_switch_on_demand)
	{
            	asm {
					mov tsp, sp
					mov tss, ss
					mov tbp, bp
				}

				PCB::running->sp = tsp;
				PCB::running->ss = tss;
				PCB::running->bp = tbp;

				putInScheduler(PCB::running);
				PCB::running = getFromScheduler();

				tsp = PCB::running->sp;
				tss = PCB::running->ss;
				tbp = PCB::running->bp;

				timeCounter = PCB::running->timeSlice;

				asm {
					mov sp, tsp
					mov ss, tss
					mov bp, tbp
				}
	}

	if (sleeping)
	{
		_temp_ = sleeping->next;
		_prev = sleeping;
		while(_temp_)
		{
			if (_temp_->sleepTime) _temp_->sleepTime--;
			if (!_temp_->sleepTime)
			{
				help = _temp_;
				_prev->next = _temp_->next;
				help->sleepf=0;
				help->next = 0;
				putInScheduler(help);
				_temp_ = _temp_->next;
			}
			else
			{
				_prev = _prev->next;
				_temp_ = _temp_->next;
			}
		}
		if (sleeping->sleepTime) sleeping->sleepTime--;
		if (!sleeping->sleepTime)
		{
			help = sleeping;
			sleeping = sleeping->next;
			help->sleepf=0;
			help->next = 0;
			putInScheduler(help);
		}
	}
	if (!context_switch_on_demand)
    {
        tick();
        asm int 60h;
	}
	else
        context_switch_on_demand = 0;
}

void timerDispatch()
{
    asm cli
    context_switch_on_demand=1;
	asm int 8h
    asm sti
}

unsigned oldTimerOFF, oldTimerSEG;

void inic(){
	asm{
		cli
		push es
		push ax

		mov ax,0
		mov es,ax

		mov ax, word ptr es:0022h
		mov word ptr oldTimerSEG, ax
		mov ax, word ptr es:0020h
		mov word ptr oldTimerOFF, ax

		mov word ptr es:0022h, seg timer
		mov word ptr es:0020h, offset timer

		mov ax, oldTimerSEG
		mov word ptr es:0182h, ax
		mov ax, oldTimerOFF
		mov word ptr es:0180h, ax

		pop ax
		pop es
		sti
	}
}

void restore(){
	asm {
		cli
		push es
		push ax

		mov ax,0
		mov es,ax


		mov ax, word ptr oldTimerSEG
		mov word ptr es:0022h, ax
		mov ax, word ptr oldTimerOFF
		mov word ptr es:0020h, ax

		pop ax
		pop es
		sti
	}
}
