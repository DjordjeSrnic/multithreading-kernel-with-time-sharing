/*
 * kernelev.h
 *
 *  Created on: Jul 19, 2018
 *      Author: OS1
 */


#ifndef KERNELEV_H_
#define KERNELEV_H_

#include "PCB.h"
#include "event.h"

typedef void interrupt (*pInterrupt)(...);
typedef unsigned char IVTNo;

class KernelEv {
public:
   KernelEv(IVTNo _ivtNo);
   ~KernelEv();
   void wait();
   void signal();
protected:
   friend class Event;
private:
   IVTNo ivtNo;
   PCB* myThreadPCB;
   PCB* blockedThreadPCB;
};

class IVTEntry {
public:
   IVTEntry(IVTNo ivtNo, pInterrupt newHandle);
   ~IVTEntry();
   static KernelEv* kEvents[256];
   void signal();
   void inic();
   void restore();
   IVTNo ivtNo;
   pInterrupt oldHandle, newHandle;
};

#endif /* KERNELEV_H_ */
