#ifndef HELP_H
#define HELP_H

#include "PCB.h"

void putInScheduler(PCB *thread);

PCB* getFromScheduler();

#endif // HELP_H
